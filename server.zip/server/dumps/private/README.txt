Dump files in this directory are encrypted and copied to 'dumps\public' during server startup

